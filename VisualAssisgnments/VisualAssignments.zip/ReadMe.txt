# Module 4 Assignment: Netflix Data Visualization

## Overview
The project is analyze Netflix content data usinn Python and R, in the following;
1.Data Preparation:
2.Data Cleaning:
3.Data Exploration:
4.Data Visualization:

## How to run th python
-- from Terminal 
bash Python visualData.py   -- it has all the functions listed above

## How to run the R
-- Use RStudio to run the r file
-- run the netflixRatings.R on the RStudio like this : source("/YourDirectory/netflixRatings.R")

#Class Dependencies
- Python: pandas, matplotlib, seaborn
- R: ggplot2

-Github URL: https://github.com/ndy-ekeh/NexFordProgramming
Branch : main
Zipfile: VisualAssignments.zip