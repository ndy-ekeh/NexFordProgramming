# Milestone Assignment 2: Principal Component Analysis :  NexFord Assignment

# Projct Overview
This project create a Milestone Assignment 2: Principal Component Analysis System with the following process:
- PCA Implementation
- Dimensionality Reduction
- Regression for prediction. : I. couldnt achieve this it's quite hard ,  but will still work on it at my spear timee


# How to eexcute 
1. Install python 3.8
2. Clone my directory
3. Execute this command :

bash
python DataSet.py

# GitHub URL: https://github.com/ndy-ekeh/NexFordProgramming.git
# branch : main
# Project folder: PCAASSIGNMENT
