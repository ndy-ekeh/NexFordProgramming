# Insurance Policy management system :  NexFord Assignment

# Projct Overview
This project create a simple Insurance Policy Management System with the following process:
- Policyholder Management
- Product Management
- Payment Processing

# How to eexcute 
1. Install python 3.8
2. Clone my directory
3. Execute this command :

bash
python mainService.py

# GitHub URL: https://github.com/ndy-ekeh/NexFordProgramming.git
# branch : main
# Project folder: InsuranceAssignment

