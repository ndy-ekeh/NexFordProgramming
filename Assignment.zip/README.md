# NexFordProgramming

- 'Hybridge.py' — Python script
- 'HighridgeSalary.R' — R script
- GitHUB URL  : https://github.com/ndy-ekeh/NexFordProgramming.git

Run:
'bash python Hybridge.py

source("HighridgeSalary.R")