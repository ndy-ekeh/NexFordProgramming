# Health Care Application Final Project :  NexFord Assignment

# Projct Overview
This project creates a trained model
- app.py


# How to eexcute 
1. Install python 3.8
2. Clone my directory
3. Execute this command :

bash
python app.py. and survey.html

# GitHub URL: https://github.com/ndy-ekeh/NexFordProgramming.git
# branch : main
# Project folder: HealthCareApplication

AWS : http://54.152.56.71/NexFordAssignment

#Dependencies
Python (Flask
pymongo
pandas
matplotlib
seaborn
jupyter) : pip install each of the values in the bracket one after the other
