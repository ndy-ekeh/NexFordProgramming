#  Fashion MNIST Classification :  NexFord Assignment

# Projct Overview
This project creates a trained model
- fashionMinstCnn.py


# How to eexcute 
1. Install python 3.8
2. Clone my directory
3. Execute this command :

bash
python fashionMinstCnn.py

# GitHub URL: https://github.com/ndy-ekeh/NexFordProgramming.git
# branch : main
# Project folder: fashionCnn

#Dependencies
Python (tensorflow, keras, matplotlib, numpy) : pip install each of the values in the. bracket one after the other
R (keras package):

install.packages("keras")
library(keras)
source("fashionMinstCnn.Rd")
